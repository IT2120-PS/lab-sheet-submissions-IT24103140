#1
setwd("C:\\Users\\it24103140\\Desktop\\IT24103140")
branch_data<-read.csv("Exercise.txt",header = TRUE)

#2
head(branch_data)
str(branch_data)

#3
boxplot(branch_data$Sales_X1,
        main="Boxplot of sales",
        ylab="Sales")

#4
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#5
  find_outliers <- function(X){
  q1<- quantile(x,0.25)
  q3< quantile(x,0.75)
  iqr<- q3-q1
  lower_bound<-q1-1.5*iqr
  upper_bound<-q3+1.5*iqr
  outliers<-x[x < lower_bound | x > upper_bound]
  if (length(outliers) == 0) return("No outliers") else return (outliers)
}
years_outliers<-find_outliers(branch_data$Years_X3)
print("Outliers in Years:")
print(years_outliers)
